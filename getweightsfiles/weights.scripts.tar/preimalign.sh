##
# Makes Lists for imalignt & imcombine
# RLB - 06.08.2007
##
# Make Lists. 
##
ls *_1.fits > fits_1.list
ls *_2.fits > fits_2.list
ls *_3.fits > fits_3.list
ls *_4.fits > fits_4.list
ls *_5.fits > fits_5.list
ls *_6.fits > fits_6.list
ls *_7.fits > fits_7.list
ls *_8.fits > fits_8.list
##
# Copy lists.
##
cp fits_1.list outfits_1.list
cp fits_2.list outfits_2.list
cp fits_3.list outfits_3.list
cp fits_4.list outfits_4.lst
cp fits_5.list outfits_5.list
cp fits_6.list outfits_6.list
cp fits_7.list outfits_7.list
cp fits_8.list outfits_8.list
##
# Edit Lists
##
vi outfits_1.list << DONE
:%s/.fits/.out.fits/g
:wq 
<< DONE
vi outfits_2.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_3.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_4.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_5.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_6.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_7.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
vi outfits_8.list << DONE
:%s/.fits/.out.fits/g
:wq
<< DONE
