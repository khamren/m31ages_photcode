##
# This Script assumes you have 6 images (1 M, 2 T2, 3 D51).
# The script will go into the .opt & .log file for each image
# and will take out the necessary information for to calculate
# image weights using "getweights".
#
# To use this script you must list the image name in order of 
# the images in the .tfr file from Daomaster.
# example: getweights.sh obj1001 obj1002 obj1003 ....
#
# THe output files will have one line for each of the three
# parameters for the input file (weights_?.inp): Readnoise,
# fwhm and median sky.
#
# Run the comanion script rmweights.sh to remove the uncessesary 
# text.
#
# RLB -- 06/08/2007
##
export image1=${1}
export image2=${2}
export image3=${3}
export image4=${4}
export image4=${5}
export image4=${6}
export image4=${7}
export image4=${8}
##
# Get Information from Image1
# Create input files for each chip
##
grep RE ${image1}_1.opt > weights_1.inp
grep FW ${image1}_1.opt >> weights_1.inp
grep Clipped ${image1}_1.log >> weights_1.inp
grep RE ${image1}_2.opt > weights_2.inp
grep FW ${image1}_2.opt >> weights_2.inp
grep Clipped ${image1}_2.log >> weights_2.inp
grep RE ${image1}_3.opt > weights_3.inp
grep FW ${image1}_3.opt >> weights_3.inp
grep Clipped ${image1}_3.log >> weights_3.inp
grep RE ${image1}_4.opt > weights_4.inp
grep FW ${image1}_4.opt >> weights_4.inp
grep Clipped ${image1}_4.log >> weights_4.inp
grep RE ${image1}_5.opt > weights_5.inp
grep FW ${image1}_5.opt >> weights_5.inp
grep Clipped ${image1}_5.log >> weights_5.inp
grep RE ${image1}_6.opt > weights_6.inp
grep FW ${image1}_6.opt >> weights_6.inp
grep Clipped ${image1}_6.log >> weights_6.inp
grep RE ${image1}_7.opt > weights_7.inp
grep FW ${image1}_7.opt >> weights_7.inp
grep Clipped ${image1}_4.log >> weights_7.inp
grep RE ${image1}_8.opt > weights_8.inp
grep FW ${image1}_8.opt >> weights_8.inp
grep Clipped ${image1}_8.log >> weights_8.inp
##
# Get Information from Image2
##
grep RE ${image2}_1.opt >> weights_1.inp
grep FW ${image2}_1.opt >> weights_1.inp
grep Clipped ${image2}_1.log >> weights_1.inp
grep RE ${image2}_2.opt >> weights_2.inp
grep FW ${image2}_2.opt >> weights_2.inp
grep Clipped ${image2}_2.log >> weights_2.inp
grep RE ${image2}_3.opt >> weights_3.inp
grep FW ${image2}_3.opt >> weights_3.inp
grep Clipped ${image2}_3.log >> weights_3.inp
grep RE ${image2}_4.opt >> weights_4.inp
grep FW ${image2}_4.opt >> weights_4.inp
grep Clipped ${image2}_4.log >> weights_4.inp
grep RE ${image2}_5.opt >> weights_5.inp
grep FW ${image2}_5.opt >> weights_5.inp
grep Clipped ${image2}_5.log >> weights_5.inp
grep RE ${image2}_6.opt >> weights_6.inp
grep FW ${image2}_6.opt >> weights_6.inp
grep Clipped ${image2}_6.log >> weights_6.inp
grep RE ${image2}_7.opt >> weights_7.inp
grep FW ${image2}_7.opt >> weights_7.inp
grep Clipped ${image2}_4.log >> weights_7.inp
grep RE ${image2}_8.opt >> weights_8.inp
grep FW ${image2}_8.opt >> weights_8.inp
grep Clipped ${image2}_8.log >> weights_8.inp
##
# Get Information from Image3
##
grep RE ${image3}_1.opt >> weights_1.inp
grep FW ${image3}_1.opt >> weights_1.inp
grep Clipped ${image3}_1.log >> weights_1.inp
grep RE ${image3}_2.opt >> weights_2.inp
grep FW ${image3}_2.opt >> weights_2.inp
grep Clipped ${image3}_2.log >> weights_2.inp
grep RE ${image3}_3.opt >> weights_3.inp
grep FW ${image3}_3.opt >> weights_3.inp
grep Clipped ${image3}_3.log >> weights_3.inp
grep RE ${image3}_4.opt >> weights_4.inp
grep FW ${image3}_4.opt >> weights_4.inp
grep Clipped ${image3}_4.log >> weights_4.inp
grep RE ${image3}_5.opt >> weights_5.inp
grep FW ${image3}_5.opt >> weights_5.inp
grep Clipped ${image3}_5.log >> weights_5.inp
grep RE ${image3}_6.opt >> weights_6.inp
grep FW ${image3}_6.opt >> weights_6.inp
grep Clipped ${image3}_6.log >> weights_6.inp
grep RE ${image3}_7.opt >> weights_7.inp
grep FW ${image3}_7.opt >> weights_7.inp
grep Clipped ${image3}_4.log >> weights_7.inp
grep RE ${image3}_8.opt >> weights_8.inp
grep FW ${image3}_8.opt >> weights_8.inp
grep Clipped ${image3}_8.log >> weights_8.inp
##
# Get Information from Image4
##
grep RE ${image4}_1.opt >> weights_1.inp
grep FW ${image4}_1.opt >> weights_1.inp
grep Clipped ${image4}_1.log >> weights_1.inp
grep RE ${image4}_2.opt >> weights_2.inp
grep FW ${image4}_2.opt >> weights_2.inp
grep Clipped ${image4}_2.log >> weights_2.inp
grep RE ${image4}_3.opt >> weights_3.inp
grep FW ${image4}_3.opt >> weights_3.inp
grep Clipped ${image4}_3.log >> weights_3.inp
grep RE ${image4}_4.opt >> weights_4.inp
grep FW ${image4}_4.opt >> weights_4.inp
grep Clipped ${image4}_4.log >> weights_4.inp
grep RE ${image4}_5.opt >> weights_5.inp
grep FW ${image4}_5.opt >> weights_5.inp
grep Clipped ${image4}_5.log >> weights_5.inp
grep RE ${image4}_6.opt >> weights_6.inp
grep FW ${image4}_6.opt >> weights_6.inp
grep Clipped ${image4}_6.log >> weights_6.inp
grep RE ${image4}_7.opt >> weights_7.inp
grep FW ${image4}_7.opt >> weights_7.inp
grep Clipped ${image4}_4.log >> weights_7.inp
grep RE ${image4}_8.opt >> weights_8.inp
grep FW ${image4}_8.opt >> weights_8.inp
grep Clipped ${image4}_8.log >> weights_8.inp
##
# Get Information from image5
##
grep RE ${image5}_1.opt >> weights_1.inp
grep FW ${image5}_1.opt >> weights_1.inp
grep Clipped ${image5}_1.log >> weights_1.inp
grep RE ${image5}_2.opt >> weights_2.inp
grep FW ${image5}_2.opt >> weights_2.inp
grep Clipped ${image5}_2.log >> weights_2.inp
grep RE ${image5}_3.opt >> weights_3.inp
grep FW ${image5}_3.opt >> weights_3.inp
grep Clipped ${image5}_3.log >> weights_3.inp
grep RE ${image5}_4.opt >> weights_4.inp
grep FW ${image5}_4.opt >> weights_4.inp
grep Clipped ${image5}_4.log >> weights_4.inp
grep RE ${image5}_5.opt >> weights_5.inp
grep FW ${image5}_5.opt >> weights_5.inp
grep Clipped ${image5}_5.log >> weights_5.inp
grep RE ${image5}_6.opt >> weights_6.inp
grep FW ${image5}_6.opt >> weights_6.inp
grep Clipped ${image5}_6.log >> weights_6.inp
grep RE ${image5}_7.opt >> weights_7.inp
grep FW ${image5}_7.opt >> weights_7.inp
grep Clipped ${image5}_4.log >> weights_7.inp
grep RE ${image5}_8.opt >> weights_8.inp
grep FW ${image5}_8.opt >> weights_8.inp
grep Clipped ${image5}_8.log >> weights_8.inp
##
# Get Information from image6
##
grep RE ${image6}_1.opt >> weights_1.inp
grep FW ${image6}_1.opt >> weights_1.inp
grep Clipped ${image6}_1.log >> weights_1.inp
grep RE ${image6}_2.opt >> weights_2.inp
grep FW ${image6}_2.opt >> weights_2.inp
grep Clipped ${image6}_2.log >> weights_2.inp
grep RE ${image6}_3.opt >> weights_3.inp
grep FW ${image6}_3.opt >> weights_3.inp
grep Clipped ${image6}_3.log >> weights_3.inp
grep RE ${image6}_4.opt >> weights_4.inp
grep FW ${image6}_4.opt >> weights_4.inp
grep Clipped ${image6}_4.log >> weights_4.inp
grep RE ${image6}_5.opt >> weights_5.inp
grep FW ${image6}_5.opt >> weights_5.inp
grep Clipped ${image6}_5.log >> weights_5.inp
grep RE ${image6}_6.opt >> weights_6.inp
grep FW ${image6}_6.opt >> weights_6.inp
grep Clipped ${image6}_6.log >> weights_6.inp
grep RE ${image6}_7.opt >> weights_7.inp
grep FW ${image6}_7.opt >> weights_7.inp
grep Clipped ${image6}_4.log >> weights_7.inp
grep RE ${image6}_8.opt >> weights_8.inp
grep FW ${image6}_8.opt >> weights_8.inp
grep Clipped ${image6}_8.log >> weights_8.inp
