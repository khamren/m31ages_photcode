mv default.jamie.sex default.sex
mv default.jamie.conv default.conv
mv default.jamie.nnw default.nnw
mv default.jamie.param default.param

cp ./default.* ./chip1/
cp ./default.* ./chip2/
cp ./default.* ./chip3/
cp ./default.* ./chip4/
cp ./default.* ./chip5/
cp ./default.* ./chip6/
cp ./default.* ./chip7/
cp ./default.* ./chip8/
